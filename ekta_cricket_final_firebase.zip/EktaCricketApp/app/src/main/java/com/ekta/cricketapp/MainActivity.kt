package com.ekta.cricketapp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.google.firebase.FirebaseApp

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this) // requires google-services.json in app/
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(30,30,30,30) }
        val title = TextView(this).apply { text = "Ekta Cricket Club by V R Rathod"; textSize = 22f }
        val btn = Button(this).apply { text = "Open App (Viewer)"; setOnClickListener { startActivity(Intent(this@MainActivity, ViewerActivity::class.java)) } }
        layout.addView(title); layout.addView(btn)
        setContentView(layout)
    }
}
