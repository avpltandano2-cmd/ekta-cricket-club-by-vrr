Ekta Cricket Club - Codemagic-ready Android project with Firebase placeholders
--------------------------------------------------------------------------
- App name: Ekta Cricket Club by V R Rathod
- Version: 1.0
- Admin login: admin / ekta123 (placeholder)

**Important: Firebase setup**
1. Create a Firebase project in Firebase Console.
2. Add an Android app with package name: com.ekta.cricketapp
3. Download the generated google-services.json
4. Place google-services.json into: EktaCricketApp/app/google-services.json
5. Commit & push to GitHub, then run build on Codemagic.
6. If using Firestore, enable Firestore rules as required.

**Build locally**
- From project root (EktaCricketApp): chmod +x gradlew && ./gradlew assembleDebug
